**************************************************
** GESTIONE JAVA
**************************************************/

Le variabili da settare sono nella classe MAIN.