package com.magicengine;

public class Token extends MagicObject {	

	public Token(int idObject) {
		super(idObject);
	}
	
	public Token(Token token, int idObject) {
		super(token, idObject);
	}

}
