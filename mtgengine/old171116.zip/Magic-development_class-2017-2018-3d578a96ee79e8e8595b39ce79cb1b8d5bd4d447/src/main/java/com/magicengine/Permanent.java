package com.magicengine;

import java.util.LinkedList;

public class Permanent extends MagicObject {

	Status status;
	private Card originCard;
	private int idBattlefield;
	private boolean transformed; // Da gestire per le carte double face
	private boolean summoningSickness;
	private boolean attacking;
	private boolean attackAlone;
	private boolean attackingAlone;
	private boolean blocking;
	private boolean blockAlone;
	private boolean blockingAlone;
	private boolean blocked;
	private boolean removedFromCombat;
	private int combatDamage;
	private int damageDealt;
	private int markedDamage;
	private int damageToAssign;

	//target di attacking e blocking
	private Target target;   //planeswalker o giocatori
	private ListPointer<Permanent> blockedCreatures;
	private ListPointer<Permanent> blockedBy;
	private ListPointer<Permanent> damageAssignmentOrder;
	
	public Permanent(Card card, int idObject, int idController, int idBattlefield)
	{
		super(card, idObject);
		this.status = new Status(false, false, true, true);
		this.originCard = card;
		this.idBattlefield = idBattlefield;
		this.transformed = false;
		this.summoningSickness = true;   //modificare in false per velocizzare test
		this.attacking = false;
		this.attackAlone = false;
		this.attackingAlone = false;
		this.blocking = false;
		this.blockAlone = false;
		this.blockingAlone = false;
		this.blocked = false;
		this.removedFromCombat = false;
		this.combatDamage = 0;
		this.damageDealt = 0;
		this.markedDamage = 0;
		this.damageToAssign = 0;
		this.setIdController(idController);
		this.target = null;
		this.blockedCreatures = new ListPointer<Permanent>(new LinkedList<Permanent>());
		this.blockedBy = new ListPointer<Permanent>(new LinkedList<Permanent>());
		this.damageAssignmentOrder = new ListPointer<Permanent>(new LinkedList<Permanent>());
	}

	// Costruttore per il PrivateGame (in caso di faceDown = true dovr� essere messa una creatura 2/2)
	public Permanent(Permanent permanent, boolean faceDown)
	{
		super(permanent, faceDown);
		this.status = permanent.getStatus();
		if(faceDown)
			this.originCard = new Card(permanent.getOriginCard(), true);
		else
			this.originCard = new Card(permanent.getOriginCard(), false);
		this.idBattlefield = permanent.getIdBattlefield();
		this.transformed = permanent.isTransformed();
		this.summoningSickness = permanent.isSummoningSickness();
		this.attacking = permanent.isAttacking();
	}
	
	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Card getOriginCard() {
		return originCard;
	}

	public void setOriginCard(Card originCard) {
		this.originCard = originCard;
	}
	
	public int getIdBattlefield() {
		return idBattlefield;
	}

	public void setIdBattlefield(int idBattlefield) {
		this.idBattlefield = idBattlefield;
	}

	public boolean isTransformed() {
		return transformed;
	}

	public void setTransformed(boolean transformed) {
		this.transformed = transformed;
	}

	public boolean isSummoningSickness() {
		return summoningSickness;
	}

	public void setSummoningSickness(boolean summoningSickness) {
		this.summoningSickness = summoningSickness;
	}

	public boolean isAttacking() {
		return attacking;
	}

	public void setAttacking(boolean attacking) {
		this.attacking = attacking;
	}

	public boolean isAttackAlone() {
		return attackAlone;
	}

	public void setAttackAlone(boolean attackAlone) {
		this.attackAlone = attackAlone;
	}

	public boolean isAttackingAlone() {
		return attackingAlone;
	}

	public void setAttackingAlone(boolean attackingAlone) {
		this.attackingAlone = attackingAlone;
	}

	public boolean isBlocking() {
		return blocking;
	}

	public void setBlocking(boolean blocking) {
		this.blocking = blocking;
	}

	public boolean isBlockAlone() {
		return blockAlone;
	}

	public void setBlockAlone(boolean blockAlone) {
		this.blockAlone = blockAlone;
	}

	public boolean isBlockingAlone() {
		return blockingAlone;
	}

	public void setBlockingAlone(boolean blockingAlone) {
		this.blockingAlone = blockingAlone;
	}

	public boolean isBlocked() {
		return blocked;
	}


	public void setBlocked(boolean blocked) {
		this.blocked = blocked;
	}

	public boolean isRemovedFromCombat() {
		return removedFromCombat;
	}

	public void setRemovedFromCombat(boolean removedFromCombat) {
		this.removedFromCombat = removedFromCombat;
	}

	public int getCombatDamage() {
		return combatDamage;
	}

	public void setCombatDamage(int combatDamage) {
		this.combatDamage = combatDamage;
	}

	public int getDamageDealt() {
		return damageDealt;
	}

	public void setDamageDealt(int damageDealt) {
		this.damageDealt = damageDealt;
	}

	public int getMarkedDamage() {
		return markedDamage;
	}

	public void setMarkedDamage(int markedDamage) {
		this.markedDamage = markedDamage;
	}

	public int getDamageToAssign() {
		return damageToAssign;
	}

	public void setDamageToAssign(int damageToAssign) {
		this.damageToAssign = damageToAssign;
	}

	public Target getTarget() {
		return target;
	}

	public void setTarget(Target target) {
		this.target = target;
	}


	public ListPointer<Permanent> getBlockedCreatures() {
		return blockedCreatures;
	}

	public void setBlockedCreatures(ListPointer<Permanent> blockedCreatures) {
		this.blockedCreatures = blockedCreatures;
	}

	public ListPointer<Permanent> getBlockedBy() {
		return blockedBy;
	}

	public void setBlockedBy(ListPointer<Permanent> blockedBy) {
		this.blockedBy = blockedBy;
	}

	public ListPointer<Permanent> getDamageAssignmentOrder() {
		return damageAssignmentOrder;
	}

	public void setDamageAssignmentOrder(ListPointer<Permanent> damageAssignmentOrder) {
		this.damageAssignmentOrder = damageAssignmentOrder;
	}

	@Override
	public void setIdController(int idController) {
		super.setIdController(idController);
		//TODO: sickness
	}
	public class Status
	{
		private boolean tapped;
		private boolean flipped;
		private boolean faceUp;
		private boolean phasedIn;
		
		public Status(boolean tapped, boolean flipped, boolean faceUp,
				boolean phasedIn) {
			super();
			this.tapped = tapped;
			this.flipped = flipped;
			this.faceUp = faceUp;
			this.phasedIn = phasedIn;
		}
		public boolean isTapped() {
			return tapped;
		}
		public void setTapped(boolean tapped) {
			this.tapped = tapped;
		}
		public boolean isFlipped() {
			return flipped;
		}
		public void setFlipped(boolean flipped) {
			this.flipped = flipped;
		}
		public boolean isFaceUp() {
			return faceUp;
		}
		public void setFaceUp(boolean faceUp) {
			this.faceUp = faceUp;
		}
		public boolean isPhasedIn() {
			return phasedIn;
		}
		public void setPhasedIn(boolean phasedIn) {
			this.phasedIn = phasedIn;
		}
	}
}
