package com.magicengine;

public interface Target {

}
