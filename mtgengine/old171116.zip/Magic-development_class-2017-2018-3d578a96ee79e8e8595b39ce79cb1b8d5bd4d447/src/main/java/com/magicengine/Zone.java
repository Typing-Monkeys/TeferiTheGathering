package com.magicengine;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Zone extends LinkedList<MagicObject> implements Target {
	
	private boolean public_zone; //hidden or public
	//private boolean shared; non c'� bisogno perch� le shared vanno su Game e le private su Player
	private String nameZone;
	
	public Zone(String nameZone, boolean isPublic) {
		super();
		this.public_zone = isPublic;
		this.nameZone = nameZone;
	}
	

	public boolean getPublic_zone() {
		return public_zone;
	}


	public void setPublic_zone(boolean public_zone) {
		this.public_zone = public_zone;
	}

	public String getNameZone() {
		return nameZone;
	}


	public void setNameZone(String nameZone) {
		this.nameZone = nameZone;
	}
	
	public void shuffle()
	{
		Collections.shuffle(this);
	}
}
