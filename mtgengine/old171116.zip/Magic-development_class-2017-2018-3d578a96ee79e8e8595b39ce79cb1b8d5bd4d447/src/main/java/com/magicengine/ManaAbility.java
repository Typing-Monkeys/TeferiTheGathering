package com.magicengine;

public class ManaAbility {
	
	public ManaAbility() {
		
	}
	
}
