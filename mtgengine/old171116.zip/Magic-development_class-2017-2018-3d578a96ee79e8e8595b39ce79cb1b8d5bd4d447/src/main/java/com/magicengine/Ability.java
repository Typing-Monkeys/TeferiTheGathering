package com.magicengine;

import java.security.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;

public class Ability extends MagicObject{


	private boolean mana_ability 		= false; // non deve essere una loyalty ability
	private boolean loyalty_ability		= false; // sono una l'inverso dell'altra false -> true; true 
	
	private boolean keyword_ability 	= false;
	private String 	keyword_text 		= "";
	
	private boolean spell_ability 		= false;
	private boolean triggered_ability	= false;
	
	private boolean targetted_ability 	= false;
	private MagicObject targetted_obj	= null;
	
	private boolean activated_ability 	= false;
	private boolean evasion_ability 	= false;
	private boolean static_ability 		= false;
	
	private boolean as_a_sorcery 		= false;

	private boolean attached_to 		= false;
	private MagicObject attached_to_obj	= null;
	
	private String 	timestamp 			= null;
	
	private MagicObject source 			= null;
	private Player owner 				= null;
	private Player controller 			= null;
	

	public Ability(int idObject, String str) {
		super(idObject);
		// TODO Auto-generated constructor stu
		this.keyword_text = str;
		System.out.println("Key: " + str );
		
		}
	

	public Ability(int idObject, boolean mana_ability, boolean keyword_ability, String keyword_text,
			boolean spell_ability, boolean triggered_ability, boolean targetted_ability, boolean activated_ability,
			boolean evasion_ability, boolean static_ability, boolean as_a_sorcery, MagicObject source,
			Player owner, Player controller, MagicObject targetted_obj) {
		super(idObject);
		this.mana_ability = mana_ability;
		this.keyword_ability = keyword_ability;
		//this.keyword_text = keyword_text;
		this.spell_ability = spell_ability;
		this.triggered_ability = triggered_ability;
		this.targetted_ability = targetted_ability;
		this.activated_ability = activated_ability;
		this.evasion_ability = evasion_ability;
		this.static_ability = static_ability;
		this.as_a_sorcery = as_a_sorcery;
		this.source = source;
		this.owner = owner;
		this.controller = controller;
		this.targetted_obj = targetted_obj;
		this.timestamp=new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	}
	
	public boolean isMana_ability() {
		return mana_ability;
	}
	public void setMana_ability(boolean mana_ability) {
		this.mana_ability = mana_ability;
	}
	public boolean isKeyword_ability() {
		return keyword_ability;
	}
	public void setKeyword_ability(boolean keyword_ability) {
		this.keyword_ability = keyword_ability;
	}
	public String getKeyword_text() {
		return keyword_text;
	}
	public void setKeyword_text(String keyword_text) {
		this.keyword_text = keyword_text;
	}
	public boolean isSpell_ability() {
		return spell_ability;
	}
	public void setSpell_ability(boolean spell_ability) {
		this.spell_ability = spell_ability;
	}
	public boolean isTriggered_ability() {
		return triggered_ability;
	}
	public void setTriggered_ability(boolean triggered_ability) {
		this.triggered_ability = triggered_ability;
	}
	public boolean isTargetted_ability() {
		return targetted_ability;
	}
	public void setTargetted_ability(boolean targetted_ability) {
		this.targetted_ability = targetted_ability;
	}
	public boolean isActivated_ability() {
		return activated_ability;
	}
	public void setActivated_ability(boolean activated_ability) {
		this.activated_ability = activated_ability;
	}
	public boolean isEvasion_ability() {
		return evasion_ability;
	}
	public void setEvasion_ability(boolean evasion_ability) {
		this.evasion_ability = evasion_ability;
	}
	public boolean isStatic_ability() {
		return static_ability;
	}
	public void setStatic_ability(boolean static_ability) {
		this.static_ability = static_ability;
	}
	public boolean isAs_a_sorcery() {
		return as_a_sorcery;
	}
	public void setAs_a_sorcery(boolean as_a_sorcery) {
		this.as_a_sorcery = as_a_sorcery;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public MagicObject getSource() {
		return source;
	}
	public void setSource(MagicObject source) {
		this.source = source;
	}
	public Player getOwner() {
		return owner;
	}
	public void setOwner(Player owner) {
		this.owner = owner;
	}
	public Player getController() {
		return controller;
	}
	public void setController(Player controller) {
		this.controller = controller;
	}
	public MagicObject getTargetted_obj() {
		return targetted_obj;
	}
	public void setTargetted_obj(MagicObject targetted_obj) {
		this.targetted_obj = targetted_obj;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (activated_ability ? 1231 : 1237);
		result = prime * result + (as_a_sorcery ? 1231 : 1237);
		result = prime * result + (attached_to ? 1231 : 1237);
		result = prime * result + ((attached_to_obj == null) ? 0 : attached_to_obj.hashCode());
		result = prime * result + ((controller == null) ? 0 : controller.hashCode());
		result = prime * result + (evasion_ability ? 1231 : 1237);
		result = prime * result + (keyword_ability ? 1231 : 1237);
		result = prime * result + ((keyword_text == null) ? 0 : keyword_text.hashCode());
		result = prime * result + (loyalty_ability ? 1231 : 1237);
		result = prime * result + (mana_ability ? 1231 : 1237);
		result = prime * result + ((owner == null) ? 0 : owner.hashCode());
		result = prime * result + ((source == null) ? 0 : source.hashCode());
		result = prime * result + (spell_ability ? 1231 : 1237);
		result = prime * result + (static_ability ? 1231 : 1237);
		result = prime * result + (targetted_ability ? 1231 : 1237);
		result = prime * result + ((targetted_obj == null) ? 0 : targetted_obj.hashCode());
		result = prime * result + ((timestamp == null) ? 0 : timestamp.hashCode());
		result = prime * result + (triggered_ability ? 1231 : 1237);
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ability other = (Ability) obj;
		if (activated_ability != other.activated_ability)
			return false;
		if (as_a_sorcery != other.as_a_sorcery)
			return false;
		if (attached_to != other.attached_to)
			return false;
		if (attached_to_obj == null) {
			if (other.attached_to_obj != null)
				return false;
		} else if (!attached_to_obj.equals(other.attached_to_obj))
			return false;
		if (controller == null) {
			if (other.controller != null)
				return false;
		} else if (!controller.equals(other.controller))
			return false;
		if (evasion_ability != other.evasion_ability)
			return false;
		if (keyword_ability != other.keyword_ability)
			return false;
		if (keyword_text == null) {
			if (other.keyword_text != null)
				return false;
		} else if (!keyword_text.equals(other.keyword_text))
			return false;
		if (loyalty_ability != other.loyalty_ability)
			return false;
		if (mana_ability != other.mana_ability)
			return false;
		if (owner == null) {
			if (other.owner != null)
				return false;
		} else if (!owner.equals(other.owner))
			return false;
		if (source == null) {
			if (other.source != null)
				return false;
		} else if (!source.equals(other.source))
			return false;
		if (spell_ability != other.spell_ability)
			return false;
		if (static_ability != other.static_ability)
			return false;
		if (targetted_ability != other.targetted_ability)
			return false;
		if (targetted_obj == null) {
			if (other.targetted_obj != null)
				return false;
		} else if (!targetted_obj.equals(other.targetted_obj))
			return false;
		if (timestamp == null) {
			if (other.timestamp != null)
				return false;
		} else if (!timestamp.equals(other.timestamp))
			return false;
		if (triggered_ability != other.triggered_ability)
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Ability [mana_ability=" + mana_ability + ", loyalty_ability=" + loyalty_ability + ", keyword_ability="
				+ keyword_ability + ", keyword_text=" + keyword_text + ", spell_ability=" + spell_ability
				+ ", triggered_ability=" + triggered_ability + ", targetted_ability=" + targetted_ability
				+ ", targetted_obj=" + targetted_obj + ", activated_ability=" + activated_ability + ", evasion_ability="
				+ evasion_ability + ", static_ability=" + static_ability + ", as_a_sorcery=" + as_a_sorcery
				+ ", attached_to=" + attached_to + ", attached_to_obj=" + attached_to_obj + ", timestamp=" + timestamp
				+ ", source=" + source + ", owner=" + owner + ", controller=" + controller + "]";
	}



}
