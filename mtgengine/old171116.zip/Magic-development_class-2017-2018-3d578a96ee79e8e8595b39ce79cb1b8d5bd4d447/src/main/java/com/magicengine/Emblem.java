package com.magicengine;

public class Emblem extends MagicObject{

	public Emblem(int idObject) {
		super(idObject);
		// TODO Auto-generated constructor stub
	}
	
	public Emblem(Emblem emblem, int idObject)
	{
		super(emblem, idObject);
	}
}
