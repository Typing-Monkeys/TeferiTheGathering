Magic
